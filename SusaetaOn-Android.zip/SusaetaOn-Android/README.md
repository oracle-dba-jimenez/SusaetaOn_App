# SusaetaOn
Android native PDF books' reader currently only for tablets devices

## Built With

* [Kotlin 1.2.41](https://kotlinlang.org/docs/reference/) - Statically typed programming language.
* [Android API 27](https://kotlinlang.org/docs/reference/) - Android "Marshmallow" is 6 version of the Android operating system. First released on May 2015.  
* [Android Studio 3.1.2](https://developer.android.com/studio/) - Integrated development environment for Google's Android operating system, built on JetBrains.  

## Authors

* **Fulvio A. Moya** - *Initial work* - [fulviomoya](https://github.com/fulviomoya)

## Acknowledgments

* **Brayan Mota Vargas** - *Explain main idea for develop this iPad app* - [bmota](https://github.com/bmota)
