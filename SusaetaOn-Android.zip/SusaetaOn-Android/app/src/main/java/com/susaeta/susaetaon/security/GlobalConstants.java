package com.susaeta.susaetaon.security;

public abstract interface GlobalConstants {
  public static final String ENCODING = "UTF-8";
  public static final String KEY_PARAM = "key";
  public static final String INIT_VECTOR_PARAM = "initVector";
}